import React, { useState, useEffect } from 'react';
import { 
  validateMisurazioni, 
  validateDensita, 
  validateScadenzeStrumenti,
  getMissingFields,
  formatDataProduzione,
  formatDate
} from '../utils/validation';
import { generatePDF, getFilename, getReportId, sharePDF } from '../utils/pdfGenerator';
import { saveReport, loadSettings } from '../utils/storage';
import { vibrateShort, vibrateSuccess, vibrateError } from '../utils/feedback';

function VehicleForm({ state, sedeIdx, vehicleIdx, pdfBytes, onUpdateData, onPdfGenerated, onBack, showToast }) {
  const sede = state.sedi[sedeIdx];
  const vehicle = sede.veicoli[vehicleIdx];
  const data = vehicle.data || {};
  const tipo = vehicle.tipo;
  const settings = loadSettings();

  const steps = tipo === '3M' 
    ? [{ id: 'batterie', title: '🔋 Batterie' }, { id: 'misure', title: '📊 Misurazioni' }, { id: 'esito', title: '✅ Esito' }]
    : [{ id: 'batterie', title: '🔋 Batterie' }, { id: 'misure', title: '📊 Misurazioni' }, { id: 'densita', title: '💧 Densità' }, { id: 'esito', title: '✅ Esito' }];

  const [currentStep, setCurrentStep] = useState(0);
  const step = steps[currentStep];

  // Wake Lock per schermo acceso
  useEffect(() => {
    let wakeLock = null;
    
    const requestWakeLock = async () => {
      if (settings.keepScreenOn && 'wakeLock' in navigator) {
        try {
          wakeLock = await navigator.wakeLock.request('screen');
          console.log('Wake Lock attivato');
        } catch (e) {
          console.log('Wake Lock non disponibile:', e);
        }
      }
    };
    
    requestWakeLock();
    
    return () => {
      if (wakeLock) {
        wakeLock.release();
        console.log('Wake Lock rilasciato');
      }
    };
  }, [settings.keepScreenOn]);

  const updateField = (field, value) => {
    onUpdateData({ [field]: value });
  };

  const handleDataProduzione = (field, value) => {
    updateField(field, formatDataProduzione(value));
  };

  // Riempi tutte le densità con il valore del primo elemento
  const fillDensita = (prefix) => {
    const firstValue = data[`${prefix}1`];
    if (!firstValue) return;
    
    vibrateShort();
    
    const updates = {};
    for (let i = 2; i <= 12; i++) {
      updates[`${prefix}${i}`] = firstValue;
    }
    onUpdateData(updates);
  };

  // Navigazione
  const nextStep = () => {
    // Validazioni per step misure
    if (step.id === 'misure') {
      const warnings = validateMisurazioni(data);
      if (warnings.length > 0) {
        vibrateError();
        showToast(warnings.join('<br>'), 'danger');
        return;
      }
    }

    // Validazioni per step densità
    if (step.id === 'densita') {
      const warnings = validateDensita(data);
      if (warnings.length > 0) {
        vibrateError();
        showToast(warnings.join('<br>'), 'danger');
        return;
      }
    }

    vibrateShort();
    setCurrentStep(prev => prev + 1);
  };

  const prevStep = () => {
    vibrateShort();
    setCurrentStep(prev => prev - 1);
  };

  // Generazione PDF
  const handleGeneratePDF = async () => {
    // Controllo campi mancanti
    const missing = getMissingFields(state, sedeIdx, vehicleIdx);
    if (missing.length > 0) {
      vibrateError();
      showToast(`⚠️ Impossibile generare PDF.<br><br>Mancano:<br>• ${missing.join('<br>• ')}`, 'danger');
      return;
    }

    // Controllo scadenze
    const scadenze = validateScadenzeStrumenti(state.strumenti, state.operatore, tipo);
    if (scadenze.length > 0) {
      vibrateError();
      showToast(scadenze.join('<br>'), 'danger');
      return;
    }

    try {
      const pdfBytesOut = await generatePDF(pdfBytes, state, sedeIdx, vehicleIdx);
      const filename = getFilename(vehicle, state.operatore);
      const reportId = getReportId(vehicle, state.operatore);

      // Salva report in IndexedDB
      await saveReport({
        id: reportId,
        veicolo: vehicle.numero,
        tipo: tipo === '3M' ? '3Mesi' : '6Mesi',
        data: formatDate(state.operatore.data),
        sede: sede.nome,
        odl: sede.odl,
        filename,
        pdfBlob: pdfBytesOut,
        createdAt: Date.now(),
        shared: false
      });

      onPdfGenerated();
      vibrateSuccess();

      // Prova a condividere, altrimenti download
      const shared = await sharePDF(pdfBytesOut, filename);
      if (shared) {
        showToast(`✅ Report "${filename}" generato!`, 'success');
      }

      onBack();
    } catch (e) {
      console.error('Errore generazione PDF:', e);
      vibrateError();
      showToast('Errore generazione PDF: ' + e.message, 'danger');
    }
  };

  // ==================== RENDER STEPS ====================
  const renderBatterie = () => (
    <>
      <div className="section-title">🔋 Pacco Batterie 1</div>
      <div className="form-row">
        <div className="form-group">
          <label>Data Produzione</label>
          <input
            type="text"
            placeholder="MM/AAAA"
            maxLength={7}
            value={data.b1Data || ''}
            onChange={(e) => handleDataProduzione('b1Data', e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Costruttore</label>
          <input
            type="text"
            value={data.b1Costr || ''}
            onChange={(e) => updateField('b1Costr', e.target.value)}
          />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label>S/N 1</label>
          <input
            type="text"
            value={data.b1Sn1 || ''}
            onChange={(e) => updateField('b1Sn1', e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>S/N 2</label>
          <input
            type="text"
            value={data.b1Sn2 || ''}
            onChange={(e) => updateField('b1Sn2', e.target.value)}
          />
        </div>
      </div>

      <div className="section-title">🔋 Pacco Batterie 2</div>
      <div className="form-row">
        <div className="form-group">
          <label>Data Produzione</label>
          <input
            type="text"
            placeholder="MM/AAAA"
            maxLength={7}
            value={data.b2Data || ''}
            onChange={(e) => handleDataProduzione('b2Data', e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Costruttore</label>
          <input
            type="text"
            value={data.b2Costr || ''}
            onChange={(e) => updateField('b2Costr', e.target.value)}
          />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label>S/N 3</label>
          <input
            type="text"
            value={data.b2Sn3 || ''}
            onChange={(e) => updateField('b2Sn3', e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>S/N 4</label>
          <input
            type="text"
            value={data.b2Sn4 || ''}
            onChange={(e) => updateField('b2Sn4', e.target.value)}
          />
        </div>
      </div>
    </>
  );

  const renderMisuraRow = (idLabel, prefix) => (
    <>
      <div className="section-title">{idLabel}</div>
      <div className="form-row" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
        <div className="form-group">
          <label>V Multi</label>
          <input
            type="number"
            step="0.01"
            value={data[`${prefix}Vm`] || ''}
            onChange={(e) => updateField(`${prefix}Vm`, e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>V Vettura</label>
          <input
            type="number"
            step="0.01"
            value={data[`${prefix}Vv`] || ''}
            onChange={(e) => updateField(`${prefix}Vv`, e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>I Vettura</label>
          <input
            type="number"
            step="0.01"
            value={data[`${prefix}Iv`] || ''}
            onChange={(e) => updateField(`${prefix}Iv`, e.target.value)}
          />
        </div>
      </div>
    </>
  );

  const renderMisure = () => (
    <>
      {renderMisuraRow('ID.2 - Carica completa', 'id2')}
      {renderMisuraRow('ID.4 - Inizio scarica', 'id4')}
      {renderMisuraRow('ID.5 - Durante scarica', 'id5')}
      {renderMisuraRow('ID.6 - Fine scarica', 'id6')}
    </>
  );

  const renderDensitaGrid = (prefix, title) => (
    <>
      <div className="section-title">{title}</div>
      <div className="densita-grid">
        {[...Array(12)].map((_, i) => (
          <div className="form-group" key={i}>
            <label>{i + 1}</label>
            <input
              type="number"
              value={data[`${prefix}${i + 1}`] || ''}
              onChange={(e) => updateField(`${prefix}${i + 1}`, e.target.value)}
            />
          </div>
        ))}
      </div>
      <button
        className="btn btn-outline btn-small fill-btn"
        onClick={() => fillDensita(prefix)}
        disabled={!data[`${prefix}1`]}
      >
        📋 Riempi tutti con "{data[`${prefix}1`] || '----'}"
      </button>
    </>
  );

  const renderDensita = () => (
    <>
      {renderDensitaGrid('p1e', '💧 Densità Pacco 1 (g/l)')}
      {renderDensitaGrid('p2e', '💧 Densità Pacco 2 (g/l)')}
    </>
  );

  const renderEsito = () => (
    <>
      <div className="section-title">✅ Esito Verifica</div>
      <div className="esito-buttons">
        <button
          className={`esito-btn ${data.esito === 'POSITIVO' ? 'selected positivo' : ''}`}
          onClick={() => updateField('esito', 'POSITIVO')}
        >
          ✅ POSITIVO
        </button>
        <button
          className={`esito-btn ${data.esito === 'NEGATIVO' ? 'selected negativo' : ''}`}
          onClick={() => updateField('esito', 'NEGATIVO')}
        >
          ❌ NEGATIVO
        </button>
      </div>

      <div className="form-group" style={{ marginTop: '20px' }}>
        <label>Note (opzionale)</label>
        <textarea
          style={{ 
            width: '100%', 
            padding: '10px 12px', 
            border: '1px solid var(--border)', 
            borderRadius: '8px',
            fontSize: '14px',
            minHeight: '80px',
            resize: 'vertical'
          }}
          value={data.note || ''}
          onChange={(e) => updateField('note', e.target.value)}
          placeholder="Eventuali note..."
        />
      </div>
    </>
  );

  const renderStepContent = () => {
    switch (step.id) {
      case 'batterie': return renderBatterie();
      case 'misure': return renderMisure();
      case 'densita': return renderDensita();
      case 'esito': return renderEsito();
      default: return null;
    }
  };

  return (
    <div className="container">
      <span className="back-link" onClick={onBack}>← Indietro</span>

      <div className="card">
        <div className="form-header">
          <h3>{vehicle.numero}</h3>
          <span className={`badge badge-${tipo.toLowerCase()}`}>
            {tipo === '3M' ? '3 Mesi' : '6 Mesi'}
          </span>
        </div>

        {/* Steps indicator */}
        <div className="steps">
          {steps.map((s, i) => (
            <div 
              key={s.id} 
              className={`step ${i < currentStep ? 'completed' : ''} ${i === currentStep ? 'active' : ''}`}
            />
          ))}
        </div>

        <h3 style={{ fontSize: '14px', marginBottom: '16px', color: 'var(--text)' }}>
          {step.title}
        </h3>

        {renderStepContent()}

        {/* Navigation buttons */}
        <div className={`nav-buttons ${currentStep === 0 ? 'single' : ''}`}>
          {currentStep > 0 && (
            <button className="btn btn-secondary" onClick={prevStep}>
              ← Indietro
            </button>
          )}
          
          {currentStep < steps.length - 1 ? (
            <button className="btn btn-primary" onClick={nextStep}>
              Avanti →
            </button>
          ) : (
            <button className="btn btn-success" onClick={handleGeneratePDF}>
              📄 Genera PDF
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default VehicleForm;
